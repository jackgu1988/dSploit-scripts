<script type="text/javascript">

	document.write('<div id="video" style="text-align:center;">');
	document.write('<embed src="http://www.dafk.net/what/lol.swf" hidden="true"></embed>');
	document.write('</div>');
	
	function timeout() {
		setTimeout('load()',1000);
	}

	function load() {
		alert('We re no strangers to love');
		alert('You know the rules and so do I');
		alert('A full commitment s what I m thinking of');
		alert('You wouldn t get this from any other guy');
		alert('I just wanna tell you how I m feeling');
		alert('Gotta make you understand');
		alert('Never gonna give you up');
		alert('Never gonna let you down');
		alert('Never gonna run around and desert you');
		alert('Never gonna make you cry');
		alert('Never gonna say goodbye');
		alert('Never gonna tell a lie and hurt you');
		alert('We ve known each other for so long');
		alert('Your heart s been aching, but');
		alert('You re too shy to say it');
		alert('Inside, we both know what s been going on');
		alert('We know the game and we re gonna play it');
		alert('And if you ask me how I m feeling');
		alert('Don t tell me you re too blind to see');
		alert('Never gonna give you up');
		alert('Never gonna let you down');
		alert('Never gonna run around and desert you');
		alert('Never gonna make you cry');
		alert('Never gonna say goodbye');
		alert('Never gonna tell a lie and hurt you');
		alert('Never gonna give you up');
		alert('Never gonna let you down');
		alert('Never gonna run around and desert you');
		alert('Never gonna make you cry');
		alert('Never gonna say goodbye');
		alert('Never gonna tell a lie and hurt you');
		alert('(Ooh, give you up)');
		alert('(Ooh, give you up)');
		alert('Never gonna give, never gonna give');
		alert('(Give you up)');
		alert('Never gonna give, never gonna give');
		alert('(Give you up)');
		alert('We ve known each other for so long');
		alert('Your heart s been aching, but');
		alert('You re too shy to say it');
		alert('Inside, we both know what s been going on');
		alert('We know the game and we re gonna play it');
		alert('I just wanna tell you how I m feeling');
		alert('Gotta make you understand');
		alert('Never gonna give you up');
		alert('Never gonna let you down');
		alert('Never gonna run around and desert you');
		alert('Never gonna make you cry');
		alert('Never gonna say goodbye');
		alert('Never gonna tell a lie and hurt you');
		alert('Never gonna give you up');
		alert('Never gonna let you down');
		alert('Never gonna run around and desert you');
		alert('Never gonna make you cry');
		alert('Never gonna say goodbye');
		alert('Never gonna tell a lie and hurt you');
		alert('Never gonna give you up');
		alert('Never gonna let you down');
		alert('Never gonna run around and desert you');
		alert('Never gonna make you cry');
		alert('Never gonna say goodbye');
		alert('Never gonna tell a lie and hurt you');
	}
</script>

<body onmouseover="timeout()">
