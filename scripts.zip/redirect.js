<script type="text/javascript">
window.onload=function() {
	redirect();
}

function redirect(){
  window.location = "http://example.com";
}
</script>
