<script language=javascript>
function redirect(){
  window.location = "http://example.com";
}
</script>

<body onload="redirect()">
